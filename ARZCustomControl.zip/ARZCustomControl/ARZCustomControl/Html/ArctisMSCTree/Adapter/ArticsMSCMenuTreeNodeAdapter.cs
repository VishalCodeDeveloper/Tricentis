﻿using System.Drawing;
using System.Linq;
using System.Threading;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;

namespace ARZCustomControl.Html.ArctisMSCTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    class ArticsMSCMenuTreeNodeAdapter : AbstractHtmlDomNodeAdapter<IHtmlElementTechnical>, ITreeNodeAdapter
    {
        #region Constructors and Destructors
        protected ArticsMSCMenuTreeNodeAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName
        {
            get {
                if (Technical.Children.Get<IHtmlSpanTechnical>().Count() > 0)
                {
                    return Technical.Children.Get<IHtmlSpanTechnical>().First().InnerText.Trim();
                }
                return Technical.InnerText.Trim();
//                return base.DefaultName;
            }
        }

        public PointF? ExpandCollapsePoint => new PointF();

        public bool Expanded => false;

        public bool Selected => false;

        public override bool Visible => Technical.Visible;

        public override bool IsSteerable => Visible && Enabled;

        public override bool Enabled
        {
            get {
                if (Technical.ClassName.ToLower().Contains("disabled"))
                {
                    return false;
                }
                return true;
            }
        }

        public string Name => DefaultName;
        #endregion

        #region Public Methods and Operators
        public void Collapse()
        {
            ClickNode();
        }

        public void Expand()
        {
            ClickNode();
        }

        public void Select()
        {
            ClickNode();
        }
        #endregion

        #region Methods
        protected virtual bool IsValid(IHtmlElementTechnical technical)
        {
            if (technical.Tag.ToLower().Equals("li"))
            {
                if (technical.ParentNode.Get<IHtmlElementTechnical>() != null && technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>() != null)
                {
                    if (technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().Id.ToLower().Equals("funktionsleiste"))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private void ClickNode()
        {
            Mouse.PerformMouseAction(MouseOperation.MouseOver, ActionPoint);

            if (Technical.Children.Get<IHtmlElementTechnical>().Count() > 0)
            {
                Technical.Children.Get<IHtmlElementTechnical>().First().Click();
            }
            else
            {
                Technical.Click();
            }
            Thread.Sleep(200);
        }
        #endregion
    }
}
