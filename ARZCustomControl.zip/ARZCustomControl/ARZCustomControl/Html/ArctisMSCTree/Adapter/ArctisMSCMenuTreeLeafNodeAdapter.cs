﻿using System.Drawing;
using System.Linq;
using System.Threading;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;

namespace ARZCustomControl.Html.ArctisMSCTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    class ArctisMSCMenuTreeLeafNodeAdapter : AbstractHtmlDomNodeAdapter<IHtmlElementTechnical>, ITreeNodeAdapter
    {
        #region Constructors and Destructors
        protected ArctisMSCMenuTreeLeafNodeAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public PointF? ExpandCollapsePoint => new PointF();

        public bool Expanded => false;

        public bool Selected => false;

        public override bool IsSteerable => Visible && Enabled;

        public override bool Visible => true;

        public override bool Enabled
        {
            get {
                if (Technical.ClassName.ToLower().Contains("disabled"))
                {
                    return false;
                }
                return true;
            }
        }

        public string Name => Technical.InnerText.Trim();
        #endregion

        #region Public Methods and Operators
        //public override RectangleF GetControlArea(bool refresh)
        //{
        //    return new RectangleF();
        //}

        public void Collapse()
        {
            Mouse.PerformMouseAction(MouseOperation.MouseOver, ActionPoint);
            Thread.Sleep(2000);

            //            ClickNode();
        }
        public void Expand()
        {
            Mouse.PerformMouseAction(MouseOperation.MouseOver, ActionPoint);
            Thread.Sleep(2000);

            //            ClickNode();
        }

        public void Select()
        {
            ClickNode();
        }
        #endregion

        #region Methods
        protected virtual bool IsValid(IHtmlElementTechnical technical)
        {
            if (technical.Tag.ToLower().Equals("li"))
            {
                if (technical.ParentNode.Get<IHtmlElementTechnical>().Tag.ToLower().Equals("li"))
                {
                    if (technical.ParentNode.Get<IHtmlElementTechnical>().ClassName.ToLower().Contains("dropdown"))
                    {
                        return true;
                    }
                }
                if (technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().Tag.ToLower().Equals("li"))
                {
                    if (technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().ClassName.ToLower().Contains("dropdown"))
                    {
                        return true;
                    }
                }
                if (technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().Tag.ToLower().Equals("li"))
                {
                    if (technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().ClassName.ToLower().Contains("dropdown"))
                    {
                        return true;
                    }
                }


            }
            return false;
        }

        private void ClickNode()
        {
            if (Technical.Children.Get<IHtmlElementTechnical>().Count() > 0)
            {
                Technical.Children.Get<IHtmlElementTechnical>().First().Click();
            }
            else
            {
                Technical.Click();
            }
            Thread.Sleep(200);
        }
        #endregion
    }
}
