﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisMSCTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlDivTechnical))]
    public class ArctisMSCMenuTreeAdapter : AbstractHtmlDomNodeAdapter<IHtmlDivTechnical>, ITreeAdapter
    {
        #region Constructors and Destructors
        protected ArctisMSCMenuTreeAdapter(IHtmlDivTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName => "Custom Arctis MSC Menu Tree";
        #endregion

        #region Public Methods and Operators
        public static bool IsValid(IHtmlDivTechnical technical)
        {
            return technical.Id.ToLower() == "actions";
        }
        #endregion

    }
}
