﻿using System.Drawing;
using System.Linq;
using System.Threading;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.DivCombobox.Adapter
{
    [SupportedTechnical(typeof(IHtmlOptionTechnical))]
    public class DivComboboxItemAdapter : HtmlListItemAdapter
    {
        #region Fields
        private DivComboboxAdapter comboBoxAdapter = null;

        private IHtmlDivTechnical comboBoxTechnical = null;

        #endregion

        #region Constructors and Destructors
        public DivComboboxItemAdapter(IHtmlOptionTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }

        private bool IsValid(IHtmlOptionTechnical technical)
        {
            IHtmlSelectTechnical parent = technical.ParentNode.Get<IHtmlSelectTechnical>();
            return parent != null && parent.HasClass("bootstrapcomboselectbox") && ComboBoxTechnical != null;
        }

        #endregion

        #region Properties
        public DivComboboxAdapter ComboBoxAdapter
        {
            get {
                if (comboBoxAdapter == null)
                {
                    comboBoxAdapter = AdapterFactory
                        .CreateAdapters<DivComboboxAdapter>(ComboBoxTechnical, "Html")
                        .FirstOrDefault();
                }
                return comboBoxAdapter;
            }
        }

        public IHtmlDivTechnical ComboBoxTechnical
        {
            get {
                if (comboBoxTechnical == null)
                {
                    comboBoxTechnical = GetComboBoxTechnical();
                }
                return comboBoxTechnical;
            }
        }

        public override string DefaultName => Text;

        public override bool Selected
        {
            get {
                return Technical.Selected;
            }
            set {
                if (value)
                {
                    if (!Technical.Selected)
                    {
                        IHtmlSpanTechnical span = GetSpan();
                        if (span != null)
                        {
                            //ExecuteMethodInvoke(span, "this.click();");
                            span.Click();
                            //ComboBoxTechnical.FireEvent("change");
                        }
                    }
                }
            }
        }

        public override string Text
        {
            get {
                IHtmlSpanTechnical htmlSpanTechnical = GetSpan();
                if (htmlSpanTechnical != null)
                {
                    return htmlSpanTechnical.Title.Trim();
                }
                else
                {
                    return GetTechnicalInnerText();
                }
            }
        }

        private string GetTechnicalInnerText()
        {
            int first = Technical.InnerText.IndexOf('>') + 1;
            int last = Technical.InnerText.LastIndexOf('<');
            int length = last - first;
            if (length < 0)
            {
                return Technical.InnerText;
            }
            return Technical.InnerText.Substring(first, length).Trim();
        }

        public override bool Visible => ComboBoxTechnical.Visible;
        #endregion

        #region Public Methods and Operators
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }
            if (ReferenceEquals(this, obj))
            {
                return true;
            }
            if (obj.GetType() != this.GetType())
            {
                return false;
            }
            return Equals((DivComboboxItemAdapter)obj);
        }

        private IHtmlDivTechnical GetComboBoxTechnical()
        {
            IHtmlElementTechnical selectTechnical = Technical.ParentNode.Get<IHtmlElementTechnical>();

            return selectTechnical
                ?.ParentNode.Get<IHtmlElementTechnical>()
                ?.Children.Get<IHtmlDivTechnical>()?.FirstOrDefault(x => x.GetAttribute("data-selectid") == selectTechnical.Id)
                ?.Children.Get<IHtmlDivTechnical>().FirstOrDefault(DivComboboxAdapter.IsDivComboBox);
        }

        public IHtmlSpanTechnical GetSpan()
        {
            string myValue = Technical.GetAttribute("value");

            IHtmlSpanTechnical activeSpan = ComboBoxTechnical.Children.Get<IHtmlSpanTechnical>().FirstOrDefault();
            if (activeSpan != null && (activeSpan.GetAttribute("value") == myValue || activeSpan.GetAttribute("data-value") == myValue))
            {
                return activeSpan;
            }

            IHtmlDivTechnical parent = ComboBoxTechnical.ParentNode.Get<IHtmlDivTechnical>();
            if (parent == null)
            {
                return null;
            }

            IHtmlDivTechnical dropdown = parent.Children.Get<IHtmlDivTechnical>().FirstOrDefault(t => t.HasClass("selectize-dropdown"));
            if (dropdown == null)
            {
                dropdown = ComboBoxTechnical.Document.Get<IHtmlDocumentTechnical>().All.Get<IHtmlDivTechnical>().FirstOrDefault(t => t.HasClass("selectize-dropdown"));
            }
            if(dropdown == null)
            {
                return null;
            }

            IHtmlDivTechnical divDropDown = dropdown.Children.Get<IHtmlDivTechnical>().FirstOrDefault(t => t.HasClass("selectize-dropdown-content"));

            if (divDropDown == null)
            {
                return null;
            }

            //IHtmlDivTechnical divDropDown = ComboBoxTechnical
            //        .ParentNode.Get<IHtmlDivTechnical>()
            //        .Children.Get<IHtmlDivTechnical>().First(t => t.HasClass("selectize-dropdown"))
            //        .Children.Get<IHtmlDivTechnical>().First(t => t.HasClass("selectize-dropdown-content"));

            IHtmlSpanTechnical span =
                divDropDown.Children.Get<IHtmlSpanTechnical>()
                           .FirstOrDefault(
                                   x =>
                                   x.GetAttribute("value") == myValue || x.GetAttribute("data-value") == myValue);
            if (span == null && Enabled && ComboBoxAdapter.IsSteerable)
            {
                ComboBoxAdapter.MouseEvent("mousedown", 0, 0, 0, 0);

                divDropDown.Refresh();
                Thread.Sleep(150);
                ComboBoxAdapter.MouseEvent("mousedown", 0, 0, 0, 0);
                span = divDropDown.Children.Get<IHtmlSpanTechnical>()
                                   .FirstOrDefault(
                                           x =>
                                           x.GetAttribute("value") == myValue || x.GetAttribute("data-value") == myValue);
            }

            return span;
        }
        #endregion

        #region Methods
        protected bool Equals(DivComboboxItemAdapter other)
        {
            string thisValue = Technical.GetAttribute("value");
            string otherValue = other.Technical.GetAttribute("value");

            return base.Equals(other) || thisValue == otherValue;
        }

        protected override RectangleF GetRefreshedControlArea(bool refreshContext)
        {
            RectangleF clientRectangle = base.GetRefreshedControlArea(refreshContext);
            return new RectangleF(0, 0, 0, 0);
        }
        #endregion
    }
}