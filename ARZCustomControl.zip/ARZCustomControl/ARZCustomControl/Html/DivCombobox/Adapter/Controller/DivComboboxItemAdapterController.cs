﻿using System.Collections.Generic;
using System.Linq;

using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Controllers.Html;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;

namespace ARZCustomControl.Html.DivCombobox.Adapter.Controller {
    [SupportedAdapter(typeof(DivComboboxItemAdapter))]
    public class DivComboboxItemAdapterController : HtmlElementContextAdapterController
            //HtmlContextAdapterController<DivComboboxItemAdapter>
    {
        #region Constructors and Destructors

        public DivComboboxItemAdapterController(DivComboboxItemAdapter contextAdapter,
                                                ISearchQuery query,
                                                Validator validator)
                : base(contextAdapter, query, validator) {
        }

        #endregion

        #region Methods

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation) {
            yield return new AlgorithmicAssociation("ParentNode");
        }

        protected override IEnumerable<IAdapter> SearchAdapters(
                IAlgorithmicAssociation algorithmicAssociation) {
            switch (algorithmicAssociation.AlgorithmName) {
                case "ParentNode":
                    IList<IAdapter> adapters =
                            base.SearchAdapters(algorithmicAssociation)
                                .OfType<DivComboboxAdapter>().OfType<IAdapter>()
                                .ToList();
                    return adapters;

                default:
                    return base.SearchAdapters(algorithmicAssociation);
            }
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(
                IAlgorithmicAssociation algorithmicAssociation) {
            if (algorithmicAssociation.AlgorithmName == "ParentNode") {
                return GetParentNode<ITechnical>();
            }
            return base.SearchTechnicals(algorithmicAssociation);
        }

        private IEnumerable<TSearchedTechnical> GetParentNode<TSearchedTechnical>()
                where TSearchedTechnical : class, ITechnical {
            TSearchedTechnical technical =
                    DivComboboxItemAdapter.GetComboBoxTechnical(ContextAdapter) as TSearchedTechnical;

            if (technical != null) {
                IList<TSearchedTechnical> result = new List<TSearchedTechnical>();
                result.Add(technical);
                return result;
            }

            return new List<TSearchedTechnical>();
        }

        #endregion
    }
}