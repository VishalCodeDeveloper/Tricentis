﻿using System.Collections.Generic;
using System.Linq;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.DivCombobox.Adapter.Controller {
    [SupportedAdapter(typeof(DivComboboxAdapter))]
    public class DivComboboxAdapterController : ListAdapterController<DivComboboxAdapter> {
        #region Constructors and Destructors
        public DivComboboxAdapterController(DivComboboxAdapter contextAdapter, ISearchQuery query, Validator validator)
                : base(contextAdapter, query, validator) {
        }

        #endregion

        #region Methods

        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation) {
            yield return new AlgorithmicAssociation("ListItems");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(
                DescendantsBusinessAssociation businessAssociation) {
            yield return new AlgorithmicAssociation("ListItems");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation) {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ListItemsBusinessAssociation businessAssociation) {

            yield return new ChildrenBusinessAssociation();
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(IAlgorithmicAssociation algorithmicAssociation) {
            if (algorithmicAssociation.AlgorithmName == "ListItems")
            {
                return GetItems();
            }
            return base.SearchTechnicals(algorithmicAssociation);
        }

        private IEnumerable<ITechnical> GetItems()
        {
            string selectToSearchFor = ContextAdapter.Technical.Id.Replace(":dropdown", "");
            IEnumerable<ITechnical> items;

            IHtmlSelectTechnical selectElement = ContextAdapter.Technical
                .ParentNode.Get<IHtmlElementTechnical>()
                .ParentNode.Get<IHtmlElementTechnical>()
                .Children.Get<IHtmlSelectTechnical>().FirstOrDefault(s => s.Id.Contains(selectToSearchFor));


            if (selectElement != null)
            {
                items = selectElement.Children.Get<IHtmlOptionTechnical>();
            }
            else
            {
                items = ContextAdapter.Technical.ParentNode.Get<IHtmlDivTechnical>()
                .ParentNode.Get<IHtmlDivTechnical>()
                .Children.Get<IHtmlSelectTechnical>().FirstOrDefault()
                .Children.Get<IHtmlOptionTechnical>();
            }
            return items;
        }
        #endregion
    }
}