﻿using System.Drawing;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Adapters.Lists;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.DivCombobox.Adapter
{
    [SupportedTechnical(typeof(IHtmlDivTechnical))]
    public class DivComboboxAdapter : AbstractHtmlDomNodeAdapter<IHtmlDivTechnical>, IComboBoxAdapter {
        #region Constructors and Destructors
        public DivComboboxAdapter(IHtmlDivTechnical technical, Validator validator)
                : base(technical, validator) {
            validator.AssertTrue(() => IsDivComboBox(technical));
        }

        #endregion

        #region Properties
        public override string DefaultName => "CustomCombobox";
    
        public override bool Enabled => !Technical.HasClass("disabled") && Visible;

        public override bool IsSteerable => Enabled && Visible;

        public override bool Visible {
            get {
                RectangleF rect = GetControlArea(true);
                return !(rect.Height < 1 || rect.Width < 1);
            }
        }
        #endregion

        #region Public Methods and Operators
        public override bool Equals(object obj) {
            if (ReferenceEquals(null, obj)) {
                return false;
            }
            if (ReferenceEquals(this, obj)) {
                return true;
            }
            if (obj.GetType() != this.GetType()) {
                return false;
            }
            return Equals((DivComboboxAdapter)obj);
        }

        public static bool IsDivComboBox(IHtmlDivTechnical htmlTechnical) {
            return htmlTechnical.HasClass("selectize-input") && htmlTechnical.HasClass("items");
        }
        #endregion

        #region Methods
        protected bool Equals(DivComboboxAdapter other) {
            return base.Equals(other) || this.Technical.Id == other.Technical.Id;
        }
        #endregion
    }
}