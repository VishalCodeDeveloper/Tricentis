﻿using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.KassaNavigationTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class KassaNavigationTreeAdapter : AbstractHtmlDomNodeAdapter<IHtmlElementTechnical>, ITreeAdapter
    {
        #region Constructors and Destructors
        protected KassaNavigationTreeAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName => "Custom Kassa Arctis Tree";
        #endregion

        #region Public Methods and Operators
        public static bool IsValid(IHtmlElementTechnical technical)
        {
            return technical.Id.ToLower() == "menuleft";
        }
        #endregion
    }
}
