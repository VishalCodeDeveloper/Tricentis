﻿using System.Collections.Generic;
using System.Linq;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.KassaNavigationTree.Adapter.Controller
{
    [SupportedAdapter(typeof(KassaNavigationTreeNodeAdapter))]
    public class KassaNavigationTreeNodeAdapterController : TreeNodeContextAdapterController<KassaNavigationTreeNodeAdapter>
    {
        #region Constants
        private const string NODES_ALG = "Nodes";
        #endregion

        #region Constructors and Destructors
        protected KassaNavigationTreeNodeAdapterController(KassaNavigationTreeNodeAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(TreeNodeBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation(NODES_ALG);
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (algorithmicAssociation.AlgorithmName == NODES_ALG)
            {
                return GetNodes();
            }
            return base.SearchTechnicals(algorithmicAssociation);
        }

        private IEnumerable<ITechnical> GetNodes()
        {
            return ContextAdapter.Technical.Children.Get<IHtmlElementTechnical>().FirstOrDefault(i => i.Tag.ToLower() == "ul")
                .Children.Get<IHtmlElementTechnical>();
        }
        #endregion
    }
}
