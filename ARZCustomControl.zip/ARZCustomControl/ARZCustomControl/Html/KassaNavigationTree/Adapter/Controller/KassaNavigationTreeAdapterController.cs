﻿using System.Collections.Generic;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;

namespace ARZCustomControl.Html.KassaNavigationTree.Adapter.Controller
{
    [SupportedAdapter(typeof(KassaNavigationTreeAdapter))]
    public class KassaNavigationTreeAdapterController : TreeContextAdapterController<KassaNavigationTreeAdapter>
    {
        #region Constants
        private const string NODES_ALG = "Nodes";
        #endregion

        #region Constructors and Destructors
        protected KassaNavigationTreeAdapterController(KassaNavigationTreeAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(TreeNodeBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }
        #endregion
    }
}
