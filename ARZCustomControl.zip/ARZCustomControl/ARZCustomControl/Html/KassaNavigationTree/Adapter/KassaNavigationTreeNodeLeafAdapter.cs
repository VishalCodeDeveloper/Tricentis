﻿using ARZCustomControl.Html.KassaNavigationTree.Adapter;
using System.Drawing;
using System.Linq;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.KassaNavigationTree
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class KassaNavigationTreeNodeLeafAdapter : KassaNavigationTreeNodeAdapter
    {
        #region Constructors and Destructors
        protected KassaNavigationTreeNodeLeafAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid);
        }
        #endregion

        #region Properties
        public override bool Expanded => false;
        
        public override string Name => Technical.InnerText;
        #endregion

        #region Public Methods and Operators
        public override PointF? ExpandCollapsePoint
        {
            get {
                IGuiAdapter spanAdapter = AdapterFactory.CreateAdapters<IGuiAdapter>(AnchorTechnical, "Html").FirstOrDefault();
                return spanAdapter?.ActionPoint ?? ActionPoint;
            }
        }
        #endregion

        #region Methods
        protected override bool IsValid()
        {
            return Technical.Tag.ToLower() == "li" && IsDescendantOfTree(Technical, 7) && !IsExpandableNode;
        }
        protected bool IsDescendantOfTree(IHtmlElementTechnical technical, int count)
        {
            IHtmlElementTechnical parentTechnical = technical.ParentNode.Get<IHtmlElementTechnical>();
            string parentTag = parentTechnical?.Tag.ToLower();

            if (count == 0 || parentTechnical == null || (parentTag != "ul" && parentTag != "li"))
            {
                return false;
            }
            if (KassaNavigationTreeAdapter.IsValid(parentTechnical))
            {
                return true;
            }
            return IsDescendantOfTree(parentTechnical, --count);
        }

        private IHtmlAnchorTechnical _anchorTechnical;
        private IHtmlAnchorTechnical AnchorTechnical
        {
            get {
                if (_anchorTechnical == null)
                {
                    _anchorTechnical = Technical.Children.Get<IHtmlAnchorTechnical>().FirstOrDefault();
                }
                return _anchorTechnical;
            }
        }
        #endregion
    }
}
