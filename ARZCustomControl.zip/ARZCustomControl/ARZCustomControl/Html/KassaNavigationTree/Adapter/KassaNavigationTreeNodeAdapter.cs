﻿using System.Drawing;
using System.Linq;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;
namespace ARZCustomControl.Html.KassaNavigationTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class KassaNavigationTreeNodeAdapter : AbstractHtmlDomNodeAdapter<IHtmlElementTechnical>, ITreeNodeAdapter
    {
        #region Constructors and Destructors
        protected KassaNavigationTreeNodeAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid);
        }
        #endregion

        #region Properties
        public virtual bool Expanded => HasExpandedClass();

        public bool Selected => Technical.HasClass("active");

        public virtual string Name => SpanTechnical.InnerText;

        private IHtmlSpanTechnical _spanTechnical;
        private IHtmlSpanTechnical SpanTechnical
        {
            get {
                if (_spanTechnical == null)
                {
                    _spanTechnical = Technical.Children.Get<IHtmlSpanTechnical>().FirstOrDefault();
                }
                return _spanTechnical;
            }
        }

        protected bool IsExpandableNode
        {
            get {
                return HasExpandedClass() || Technical.HasClass("closed");
            }
        }

        public virtual PointF? ExpandCollapsePoint
        {
            get {
                IGuiAdapter spanAdapter = AdapterFactory.CreateAdapters<IGuiAdapter>(SpanTechnical, "Html").FirstOrDefault();
                return spanAdapter?.ActionPoint ?? ActionPoint;
            }
        }
        #endregion

        #region Public Methods and Operators
        public void Expand()
        {
            ClickNode();
        }

        public void Select()
        {
            ClickNode();
        }

        public void Collapse()
        {
            ClickNode();
        }
        #endregion

        #region Methods
        private void ClickNode()
        {
            Mouse.Jumpy.DoMouseAction(MouseOperation.Click, ExpandCollapsePoint ?? ActionPoint);
        }

        protected virtual bool IsValid()
        {
            bool isVal = Technical.Tag.ToLower() == "li" && IsExpandableNode;
            return isVal;
        }

        private bool HasExpandedClass()
        {
            return Technical.HasClass("opened");
        }
        #endregion
    }
}
