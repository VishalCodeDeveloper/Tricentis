﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.SpanTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlDescriptionBaseTechnical))]
    class ArctisNestedTableAdapter : AbstractHtmlDomNodeAdapter<IHtmlDescriptionBaseTechnical>, ITableAdapter
    {
        #region Constructors and Destructors
        public ArctisNestedTableAdapter(IHtmlDescriptionBaseTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsNestedArctisTable(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName
        {
            get {
                return "Nested Table " + base.DefaultName;

            }
        }

        public bool Is2ndLevel=> Technical.KeyContains("2ndlevel");
        public LoadStrategy LoadStrategy => LoadStrategy.Default;
        #endregion

        //public int TableIndex {
        //    get {
        //        List<IHtmlElementTechnical> allSiblings = Technical
        //        ?.ParentNode.Get<IHtmlElementTechnical>()
        //        ?.Children.Get<IHtmlElementTechnical>().ToList() ?? new List<IHtmlElementTechnical>();

        //        if (allSiblings.Count < 2)
        //        {
        //            return 1;
        //        }

        //       return allSiblings.IndexOf(Technical);
        //    }
        //}

        #region Methods
        private bool IsNestedArctisTable(IHtmlDescriptionBaseTechnical technical)
        {
            return (technical.TagEquals("dt") || technical.TagEquals("dd"))
                && technical.KeyContains("listplus2")
                /*&& technical.ParentNode.Get<IHtmlElementTechnical>().IdEquals("listplus2")*/;
        }
        #endregion
    }
}
