﻿using ARZCustomControl.Html.ArctisTable.Adapter;
using ARZCustomControl.Html.SpanTable.Adapter;
using System;
using System.Collections.Generic;
using System.Linq;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Engines.Adapters;

namespace ARZCustomControl.Html.ArctisNestedTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisNestedTableAdapter))]
    class ArctisNestedTableAdapterController : TableContextAdapterController<ArctisNestedTableAdapter>
    {
        #region Constructors and Destructors
        public ArctisNestedTableAdapterController(ArctisNestedTableAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(DescendantsBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("All");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(RowsBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("rows");
        }


        protected override IEnumerable<IAssociation> ResolveAssociation(ColumnsBusinessAssociation businessAssociation)
        {
            throw new NotSupportedException();
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(
            IAlgorithmicAssociation algorithmicAssociation)
        {
            IEnumerable<IHtmlElementTechnical> searchedTechnicals = new List<IHtmlElementTechnical>();
            switch (algorithmicAssociation.AlgorithmName)
            {
                case ("rows"):
                    return GetRows();
            }
            return searchedTechnicals.OfType<ITechnical>();
        }

        private IEnumerable<ITechnical> GetRows()
        {
            List<IHtmlElementTechnical> rows = new List<IHtmlElementTechnical>();
            //var list2Items = ContextAdapter.Technical
            //    .ParentNode.Get<IHtmlElementTechnical>()
            //    .ParentNode.Get<IHtmlElementTechnical>()
            //    .ParentNode.Get<IHtmlElementTechnical>()
            //    .ParentNode.Get<IHtmlElementTechnical>()
            //    .All.Get<IHtmlElementTechnical>()
            //    .Where(t => (t.IdEquals("listplus2")));

            IHtmlElementTechnical listPlus2HeaderContainer = ContextAdapter.Technical.GetParentWithId("listplus2", 30, 1);
            if (listPlus2HeaderContainer != null) {
                string inHtml = listPlus2HeaderContainer.InnerHtml;
                List<IHtmlElementTechnical> headers = listPlus2HeaderContainer.GetAllSubTechs(6).Where(x => x.TagEquals("dt") && x.IdEquals("head")).ToList();

                foreach (var item in headers)
                {
                    string key = item.Key();
                    string id = item.Id;
                    string classNam = item.ClassName;
                }
                // IHtmlElementTechnical listPlus2HeaderContainer = list2Items.First();//header row container
                IHtmlElementTechnical headerRow = null;
                if (ContextAdapter.Is2ndLevel)
                {
                    headerRow = headers.LastOrDefault();//listPlus2HeaderContainer.Children.Get<IHtmlElementTechnical>().LastOrDefault(); //2nd lvl subtable
                }
                else //1st level
                {

                    headerRow = headers.FirstOrDefault();// listPlus2HeaderContainer.Children.Get<IHtmlElementTechnical>().FirstOrDefault(); //1st lvl subtable
                }
                rows.Add(headerRow);
            }
           

            IHtmlElementTechnical parent = ContextAdapter.Technical.ParentNode.Get<IHtmlElementTechnical>();
            string parentTag = parent.Tag;
            List<IHtmlElementTechnical> subtechs = parent.GetAllSubTechs();
            List<IHtmlElementTechnical> allSiblings = subtechs.Where(x => x.IsDtDd()).ToList();
            int indexOfNextSibling = allSiblings.IndexOf(ContextAdapter.Technical) + 1;
            
            IHtmlElementTechnical sibling = ContextAdapter.Technical;
            while(indexOfNextSibling != 0 && indexOfNextSibling < allSiblings.Count()) {
                sibling = allSiblings[indexOfNextSibling];// sibling.GetNextSiblingUsingAll();
                string tag = sibling.Tag;
                string key = sibling.Key();
                string id = sibling.Id;
                string classNam = sibling.ClassName;
                string t = sibling.InnerHtml;

                if (ContextAdapter.Is2ndLevel)
                {
                    if (sibling.Key() == null)
                    {
                        rows.Add(sibling);
                    }
                    else 
                    { // only break if higher level is detected
                        break;
                    }
                }
                else //1st level
                {
                    if (sibling.KeyContains(ContextAdapter.Technical.Key()))
                    {
                        rows.Add(sibling);
                    }
                    else if (sibling.Key() != null)
                    { // only break if higher level is detected
                        break;
                    }
                }
               
                indexOfNextSibling++;
            } ;

            foreach (var item in rows)
            {
                string tag = item.Tag;
                string key = item.Key();
                string id = item.Id;
                string classNam = item.ClassName;
                string t = item.InnerHtml;
            }
            return rows;
        }

        protected override IEnumerable<IAdapter> SearchAdapters(IAlgorithmicAssociation algorithmicAssociation)
        {
            List<IAdapter> adapters = base.SearchAdapters(algorithmicAssociation).ToList();

            foreach (var a in adapters)
            {
                if (a is ArctisRowAdapter) {
                    string t = a.Technical.ToString();
                }
            }
            return adapters;
        }
        #endregion
    }
}
