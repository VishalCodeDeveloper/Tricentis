﻿using System;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisLink
{
    [SupportedTechnical(typeof(IHtmlAnchorTechnical))]
    public class ArctisMenuLinkAdapter : HtmlLinkAdapter, IHtmlLinkAdapter
    {
        protected ArctisMenuLinkAdapter(IHtmlAnchorTechnical htmlTechnical, Validator validator) : base(htmlTechnical, validator)
        {
            validator.AssertTrue(IsValid(Technical));
        }

        private bool IsValid(IHtmlAnchorTechnical technical)
        {
            return Technical.ParentNode.Get<IHtmlElementTechnical>().Id == "dropmenudiv";
        }

        public override bool IsSteerable => true;

       // public override bool Visible => true;

        public override string DefaultName => "ArctisMenuLink: " + Label;
        
    }
}
