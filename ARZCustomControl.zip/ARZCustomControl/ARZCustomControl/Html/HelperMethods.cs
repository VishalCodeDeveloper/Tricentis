﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Common.Helpers;

namespace ARZCustomControl.Html
{
    public static class HelperMethods
    {
        public static bool HasClass(this IHtmlElementTechnical technical, string classname)
        {
            return technical.ClassName.ToLower().Split(' ').Contains(classname.ToLower());
        }

        public static bool IdEquals(this IHtmlElementTechnical technical, string id)
        {
            return technical.Id.ToLower().Equals(id.ToLower());
        }
        public static bool IdContains(this IHtmlElementTechnical technical, string content)
        {
            return technical.Id.ToLower().Contains(content.ToLower());
        }

        public static bool TagEquals(this IHtmlElementTechnical technical, string tag)
        {
            return technical.Tag.ToLower().Equals(tag.ToLower());
        }
        
        public static bool KeyContains(this IHtmlElementTechnical technical, string content)
        {
            return technical.Key() != null && technical.Key().ToLower().Contains(content.ToLower());
        }
        public static bool KeyEquals(this IHtmlElementTechnical technical, string content)
        {
            return technical.Key() != null && technical.Key().ToLower().Equals(content.ToLower());
        }

        public static string Key(this IHtmlElementTechnical technical)
        {
            return technical.GetAttribute("key");
        }


        public static IHtmlElementTechnical GetNextSibling(this IHtmlElementTechnical technical)
        {
            List<IHtmlElementTechnical> allSiblings = technical
                ?.ParentNode.Get<IHtmlElementTechnical>()
                ?.Children.Get<IHtmlElementTechnical>().ToList() ?? new List<IHtmlElementTechnical>();

           
            if (allSiblings.Count < 2)
            {
                return null;
            }

            int indexOfNextSibling = allSiblings.IndexOf(technical) + 1;
            if (indexOfNextSibling == 0 || indexOfNextSibling == allSiblings.Count)
            {
                return null;
            }
            return allSiblings.ElementAt(indexOfNextSibling);
        }

        
        /// <summary>
        /// Special logic for Arctis Nested Tables where the F12 tools and the XScan show different DOM structure, likely due
        /// to ill-formed HTML tags. To compensate for this, .All is used to be structure agnostic.
        /// </summary>
        /// <returns></returns>
        public static IHtmlElementTechnical GetNextSiblingUsingAll(this IHtmlElementTechnical technical)
        {
            string k = technical.Key();
            string ta = technical.Tag;

            IHtmlElementTechnical parent = technical?.ParentNode.Get<IHtmlElementTechnical>();
            string parentTag = parent.Tag;

            //IHtmlElementTechnical grandParent = parent?.ParentNode.Get<IHtmlElementTechnical>();
            //string grandParentTag = grandParent.Tag;
            //IHtmlElementTechnical grandParentFirstchild = grandParent.Children.Get<IHtmlElementTechnical>().FirstOrDefault();
            //List<IHtmlElementTechnical> allChildSiblings = grandParentFirstchild?.Children.Get<IHtmlElementTechnical>().ToList();
            //IHtmlElementTechnical child2 = grandParent.Children.Get<IHtmlElementTechnical>().FirstOrDefault(c => c.IdEquals("listplus2_1"));
            //List<IHtmlElementTechnical> allChild2Siblings = child2?.Children.Get<IHtmlElementTechnical>().ToList();

            List<IHtmlElementTechnical> allDtddSiblings = technical
               ?.All.Get<IHtmlElementTechnical>().Where(r => r.IsDtDd()).ToList();

            List<IHtmlElementTechnical> allDtddSiblings2 = technical
                ?.ParentNode.Get<IHtmlElementTechnical>()
               ?.All.Get<IHtmlElementTechnical>().Where(r => r.IsDtDd()).ToList();

            List<IHtmlElementTechnical> subtechs =  GetAllSubTechs(parent);
            List<IHtmlElementTechnical> allSiblings = subtechs.Where(x => x.IsDtDd()).ToList();

            foreach (IHtmlElementTechnical tech in allSiblings)
            {
                string tag12 = tech.Tag;
                string key = tech.Key();
            }

            //List<IHtmlElementTechnical> allSiblings = technical
            //    ?.ParentNode.Get<IHtmlElementTechnical>()
            //    ?.All.Get<IHtmlElementTechnical>().ToList() ?? new List<IHtmlElementTechnical>();


            IHtmlElementTechnical firstChild = allSiblings.FirstOrDefault();

            string ke = firstChild.Key();
            string tag2 = firstChild.Tag;
            string idChild = firstChild.Id;
            string innertext = firstChild.InnerHtml;

            if (allSiblings.Count < 2)
            {
                return null;
            }

            int indexOfNextSibling = allSiblings.IndexOf((IHtmlElementTechnical)technical) + 1;
            if (indexOfNextSibling == 0 || indexOfNextSibling == allSiblings.Count)
            {
                return null;
            }
            return allSiblings.ElementAt(indexOfNextSibling);
        }

        public static IHtmlElementTechnical GetPreviousSibling(this IHtmlElementTechnical technical)
        {
            List<IHtmlElementTechnical> allSiblings = technical
                ?.ParentNode.Get<IHtmlElementTechnical>()
                ?.Children.Get<IHtmlElementTechnical>().ToList() ?? new List<IHtmlElementTechnical>();


            if (allSiblings.Count < 2)
            {
                return null;
            }

            int indexOfPreviousSibling = allSiblings.IndexOf(technical) - 1;
            if (indexOfPreviousSibling < 0)
            {
                return null;
            }
            return allSiblings.ElementAt(indexOfPreviousSibling);
        }

        public static List<IHtmlElementTechnical> GetAllSubTechs(this IHtmlElementTechnical technical, int depth = 999)
        {
            List<IHtmlElementTechnical> siblingTechnicals = new List<IHtmlElementTechnical>
            {
                technical
            };

            string tag = technical.Tag;
            string key = technical.Key();
            string id = technical.Id;
            string classNam = technical.ClassName;
            string t = technical.InnerHtml;

            if (depth != 0) {
                List<IHtmlElementTechnical> children = technical?.Children.Get<IHtmlElementTechnical>().ToList();

                if (children.Count == 0) {
                    return siblingTechnicals;
                }
                foreach (IHtmlElementTechnical tech in children)
                {
                    string tag2 = tech.Tag;
                    string key2 = tech.Key();
                    string id2 = tech.Id;
                    string classNam2 = tech.ClassName;
                    string t2 = tech.InnerHtml;

                    siblingTechnicals.AddRange(tech.GetAllSubTechs(--depth));
                }
            }
            
            return siblingTechnicals;
        }

        public static bool IsDtDd(this IHtmlElementTechnical technical)
        {
            return technical.TagEquals("dd") || technical.TagEquals("dt");
        }

        public static IHtmlElementTechnical GetParentWithId(this IHtmlElementTechnical startElement, string searchString, int level, int offset = 0)
        {
            IHtmlElementTechnical elementToCheck = startElement.ParentNode.Get<IHtmlElementTechnical>();

            for (int i = 0; i < level; i++)
            {
                if (elementToCheck.IdEquals(searchString))
                {
                    if (offset == 0)
                    {
                        return elementToCheck;
                    }
                    else {
                        offset--;
                    }
                }
                elementToCheck = elementToCheck.ParentNode.Get<IHtmlElementTechnical>();
                if(elementToCheck == null) {
                    return null;
                }
            }
            return null;
        }
    }
}
