﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;

namespace ARZCustomControl.Html.ArctisRichTextbox.Adapter
{
    [SupportedTechnical(typeof(IHtmlDOMNodeTechnical))]
    public class ArctisRichTextboxAdapter : AbstractHtmlDomNodeAdapter<IHtmlDOMNodeTechnical>, ITextBoxAdapter
    {

        #region Construstor

        protected ArctisRichTextboxAdapter(IHtmlDOMNodeTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsValidRichTextbox(technical));
        }

        #endregion

        #region Properties

        public override string DefaultName => "CustomRichTextbox";

        #endregion

        #region Interface implementation

        public string Text
        {
            get 
            {
                return Technical.InnerText;
            }
            set 
            {
                //for (int i = Technical.InnerHtml.Length - 1; i > 0; i--)
                //{
                //    Technical.InnerHtml.Remove(i);
                //}
                Keyboard keyboard = new Keyboard();
                keyboard.Type(value);
            }
        }

        public bool IsPasswordField => false;

        public bool IsMultilineField => true;

        #endregion

        #region Methods

        public static bool IsValidRichTextbox(IHtmlDOMNodeTechnical technical)
        {
            return technical.Id.Equals("tinymce");
        }

        #endregion
    }
}
