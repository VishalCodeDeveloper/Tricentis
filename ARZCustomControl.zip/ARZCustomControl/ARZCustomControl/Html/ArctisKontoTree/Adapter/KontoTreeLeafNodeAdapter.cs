﻿using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlAnchorTechnical))]
    class KontoTreeLeafNodeAdapter : KontoTreeNodeAdapter
    {
        #region Constructors and Destructors
        protected KontoTreeLeafNodeAdapter(IHtmlAnchorTechnical technical, Validator validator) : base(technical, validator)
        {
        }
        #endregion

        #region Methods
        protected override bool IsValid(IHtmlAnchorTechnical technical)
        {
            return IsDescendantOfTree(Technical, 5);
        }
        #endregion
    }
}
