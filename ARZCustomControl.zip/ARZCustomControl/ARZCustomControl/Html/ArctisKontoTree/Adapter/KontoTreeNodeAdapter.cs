﻿using System.Drawing;
using System.Linq;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlAnchorTechnical))]
    public class KontoTreeNodeAdapter : AbstractHtmlDomNodeAdapter<IHtmlAnchorTechnical>, ITreeNodeAdapter
    {
        #region Constants
        private const string NODES_CONTAINER_CLASS = "itCon";
        #endregion

        #region Constructors and Destructors
        protected KontoTreeNodeAdapter(IHtmlAnchorTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public PointF? ExpandCollapsePoint => ActionPoint;

        public bool Expanded => Selected;

        public bool Selected => Technical.Children.Get<IHtmlElementTechnical>().Any(i => i.Tag.ToLower() == "b");

        public string Name => Technical.InnerText;

        private IHtmlElementTechnical _nodesContainer;
        public IHtmlElementTechnical NodesContainer
        {
            get {
                if (_nodesContainer == null)
                {
                    _nodesContainer = Technical.GetNextSibling();
                }
                return _nodesContainer;
            }
        }
        #endregion

        #region Public Methods and Operators
        public void Collapse()
        {
            ClickNode();
        }

        public void Expand()
        {
            ClickNode();
        }

        public void Select()
        {
            ClickNode();
        }
        #endregion

        #region Methods
        private void ClickNode()
        {
            Technical.Click();
        }

        protected virtual bool IsValid(IHtmlAnchorTechnical technical)
        {
            return IsDescendantOfTree(Technical, 5) && (NodesContainer?.HasClass(NODES_CONTAINER_CLASS) ?? false);
        }

        protected bool IsDescendantOfTree(IHtmlElementTechnical technical, int count)
        {
            IHtmlElementTechnical parentTechnical = technical.ParentNode.Get<IHtmlElementTechnical>();
            if (count == 0 || parentTechnical == null)
            {
                return false;
            }
            if (KontoTreeAdapter.IsValid(parentTechnical) || parentTechnical.HasClass(NODES_CONTAINER_CLASS))
            {
                return true;
            }
            return IsDescendantOfTree(parentTechnical, --count);
        }
        #endregion
    }
}
