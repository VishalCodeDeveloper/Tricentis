﻿using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlSpanTechnical))]
    public class KontoTreeAdapter : AbstractHtmlDomNodeAdapter<IHtmlSpanTechnical>, ITreeAdapter
    {
        #region Constructors and Destructors
        protected KontoTreeAdapter(IHtmlSpanTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName => "Custom ArctisKonto Tree";
        #endregion

        #region Methods
        public static bool IsValid(IHtmlElementTechnical technical)
        {
            return technical.Id.ToLower() == "ml";
        }
        #endregion
    }
}