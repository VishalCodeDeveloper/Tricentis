﻿using System;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Generic;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.SpanTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    class ArctisSubTableRowAdapter : AbstractHtmlElementAdapter<IHtmlElementTechnical>, ITableRowAdapter<IHtmlElementTechnical>
    {
        #region Constructors and Destructors
        public ArctisSubTableRowAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsArctisRow(technical));
        }
        #endregion

        #region Public Properties
        public IHtmlSpanTechnical Technical { get; }
        #endregion

        #region Methods
        private bool IsArctisRow(IHtmlElementTechnical technical)
        {
            try
            {
                return technical.Tag.ToLower().Equals("dt") && technical.GetAttribute("key").Contains("2ndLevel");
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion
    }
}
