﻿using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisSubTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlSpanTechnical))]
    class ArctisSubTableAdapter : AbstractHtmlDomNodeAdapter<IHtmlSpanTechnical>, ITableAdapter
    {

        #region Constructors and Destructors
        public ArctisSubTableAdapter(IHtmlSpanTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsArctisTable(technical));
        }
        #endregion

        #region Public Properties
        public override string DefaultName
        {
            get { return "ArctisSubTable"; }
        }

        public LoadStrategy LoadStrategy => LoadStrategy.Default;
        #endregion

        #region Methods
        private bool IsArctisTable(IHtmlSpanTechnical technical)
        {
            return technical.Id.Contains("ListPlus1");

        }
        #endregion
    }
}
