﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisSubTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisSubTableAdapter))]
    class ArctisSubTableAdapterController : TableContextAdapterController<ArctisSubTableAdapter>
    {
        #region Constructors and Destructors
        public ArctisSubTableAdapterController(ArctisSubTableAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(DescendantsBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("All");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(RowsBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("rows");
        }


        protected override IEnumerable<IAssociation> ResolveAssociation(ColumnsBusinessAssociation businessAssociation)
        {
            throw new NotSupportedException();
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(
            IAlgorithmicAssociation algorithmicAssociation)
        {
            IEnumerable<IHtmlElementTechnical> searchedTechnicals = new List<IHtmlElementTechnical>();
            switch (algorithmicAssociation.AlgorithmName)
            {
                case ("rows"):
                    var technicals = ContextAdapter.Technical.All.Get<IHtmlElementTechnical>().ToList();
                    searchedTechnicals = technicals.Where(technical => (technical.Tag.ToLower().Equals("dt")));
                    break;
            }
            return searchedTechnicals.OfType<ITechnical>();
        }
        #endregion
    }
}
