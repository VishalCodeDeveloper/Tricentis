﻿using System;
using System.Collections.Generic;
using ARZCustomControl.Html.SpanTable.Adapter;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisSubTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisSubTableRowAdapter))]
    class ArctisRowAdapterController : TableRowContextAdapterController<ArctisSubTableRowAdapter>
    {
        #region Constructors and Destructors
        public ArctisRowAdapterController(ArctisSubTableRowAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("All");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(DescendantsBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("All");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(CellsBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("All");
        }
        #endregion

       
    }
}
