﻿using System;
using System.Drawing;
using System.Linq;
using System.Threading;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;

namespace ARZCustomControl.Html.ArctisMenuTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlAnchorTechnical))]
    class ArctisMenuTreeNodeAdapter : AbstractHtmlDomNodeAdapter<IHtmlAnchorTechnical>, ITreeNodeAdapter
    {
        #region Constructors and Destructors
        protected ArctisMenuTreeNodeAdapter(IHtmlAnchorTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }

        #endregion

        #region Properties
        public PointF? ExpandCollapsePoint => null;

        public bool Expanded => false;

        public bool Selected => false;

        public override string DefaultName => Name;

        public override bool Enabled => true;

        //public override RectangleF GetControlArea(bool refresh)
        //{
        //    return new RectangleF();
        //}

        public override bool Visible => true;

        public override void SetFocus()
        {
        }

        public override void ScrollToVisible()
        {
        }

        public override bool IsSteerable => true;

        public string Name => Technical.InnerText.Trim();

        #endregion

        #region Public Methods and Operators
        public static IHtmlDivTechnical GetDropDownDiv(IHtmlElementTechnical technical)
        {
            return technical.Document.Get<IHtmlDocumentTechnical>()
                .Body.Get<IHtmlDOMNodeTechnical>()
                .Children.Get<IHtmlDivTechnical>().FirstOrDefault(i => i.Id.ToLower() == "dropmenudiv");
        }

        public void Expand()
        {
            Mouse.PerformMouseAction(MouseOperation.MouseOver, ActionPoint);
            Thread.Sleep(2000);
            //            ClickNode();
        }

        public void Select()
        {
            ClickNode();
        }

        public void Collapse()
        {
            Mouse.PerformMouseAction(MouseOperation.MouseOver, ActionPoint);
            Thread.Sleep(2000);

            //            ClickNode();
        }
        #endregion

        #region Methods
        private void ClickNode()
        {
            //Mouse.PerformMouseAction(MouseOperation.Click, ActionPoint);
            Technical.Click();
            Technical.FireEvent("click");
            Technical.FireEvent("change");
            Thread.Sleep(250);
            //GetDropDownDiv(Technical)?.Refresh();
        }

        protected virtual bool IsValid(IHtmlAnchorTechnical technical)
        {
            if (technical.ParentNode.Get<IHtmlElementTechnical>() == null)
            {
                return false;
            }

            return technical.ParentNode.Get<IHtmlElementTechnical>()?.Tag?.ToLower() == "h1";
            //return (technical.Tag.ToLower() == "i" || technical.Tag.ToLower() == "a" )
            //    && technical.ParentNode.Get<IHtmlElementTechnical>().Tag.ToLower() == "h1";
        }
        #endregion
    }
}
