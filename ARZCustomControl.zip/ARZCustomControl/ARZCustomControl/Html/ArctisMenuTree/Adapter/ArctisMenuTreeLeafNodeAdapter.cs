﻿using System;
using System.Drawing;
using System.Linq;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;

namespace ARZCustomControl.Html.ArctisMenuTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlAnchorTechnical))]
    class ArctisMenuTreeLeafNodeAdapter : ArctisMenuTreeNodeAdapter
    {
        #region Constructors and Destructors
        protected ArctisMenuTreeLeafNodeAdapter(IHtmlAnchorTechnical technical, Validator validator) : base(technical, validator)
        {
        }
        #endregion

        #region Public Methods and Operators
        public static bool IsValidDropDownMenuDiv(IHtmlDivTechnical technical)
        {
            if (technical == null)
            {
                return false;
            }
            return technical.Id.ToLower() == "dropmenudiv";
        }
        #endregion

        #region Methods
        protected override bool IsValid(IHtmlAnchorTechnical technical)
        {
            return IsValidDropDownMenuDiv(technical.ParentNode.Get<IHtmlDivTechnical>());
        }
        #endregion
    }
}
