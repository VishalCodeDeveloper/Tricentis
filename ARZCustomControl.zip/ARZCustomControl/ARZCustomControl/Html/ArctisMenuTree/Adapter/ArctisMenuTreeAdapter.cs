﻿using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisMenuTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlSpanTechnical))]
    public class ArctisMenuTreeAdapter : AbstractHtmlDomNodeAdapter<IHtmlSpanTechnical>, ITreeAdapter
    {
        #region Constructors and Destructors
        protected ArctisMenuTreeAdapter(IHtmlSpanTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName => "Custom Arctis Menu Tree";
        #endregion

        #region Public Methods and Operators
        public static bool IsValid(IHtmlSpanTechnical technical)
        {
            return technical.Id.ToLower() == "bl";
        }
        #endregion
    }
}
