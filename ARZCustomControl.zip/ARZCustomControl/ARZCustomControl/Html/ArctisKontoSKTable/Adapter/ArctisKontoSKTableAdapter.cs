﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoSKTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class ArctisKontoSKTableAdapter : AbstractHtmlDomNodeAdapter<IHtmlElementTechnical>, ITableAdapter
    {
        #region Constructor

        protected ArctisKontoSKTableAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsValidArctisSKTableTable(technical));
        }

        #endregion

        #region Properties

        public override string DefaultName => "Custom Arctis Konto SK Table";

        public LoadStrategy LoadStrategy => LoadStrategy.Default;

        #endregion

        #region Methods

        private bool IsValidArctisSKTableTable(IHtmlDOMNodeTechnical technical)
        {
            try
            {
                if(technical.Tag.ToLower().Equals("dl") && technical.Id.Equals("ListSimple1") && technical.GetAttribute("class") != null 
                    && technical.GetAttribute("class").ToLower().Equals("list"))
                {
                    return true;
                }
            }
            catch
            {
            }
            return false;
        }

        #endregion

    }
}
