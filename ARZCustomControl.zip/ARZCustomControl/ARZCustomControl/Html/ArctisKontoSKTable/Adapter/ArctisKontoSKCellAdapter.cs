﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Generic;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoSKTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class ArctisKontoSKCellAdapter : AbstractHtmlElementAdapter<IHtmlElementTechnical>, ITableCellAdapter<IHtmlElementTechnical>
    {
        #region Constructors

        protected ArctisKontoSKCellAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsArctisKontoSKCell(technical));
        }

        #endregion

        #region properties

        public ArctisKontoSKCellAdapter NextSiblingCell { get; set; }

        public int ColSpan => 1;

        public int RowSpan => 1;

        public string Text
        {
            get {
                if (NextSiblingCell != null)
                {
                    return ((IHtmlElementTechnical)NextSiblingCell.Technical).InnerText;
                }
                return Technical.InnerText;
            }
        }

        #endregion

        private bool IsArctisKontoSKCell(IHtmlElementTechnical technical)
        {
            try
            {
                if (technical.TagEquals("q"))
                {
                    return true;
                }
                return false;
            }
            catch (Exception)
            {

                return false;
            }
        }
    }
}
