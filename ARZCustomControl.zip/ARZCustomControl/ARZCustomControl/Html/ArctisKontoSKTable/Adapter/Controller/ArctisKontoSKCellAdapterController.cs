﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Tricentis.Automation.AutomationInstructions.TestActions;
//using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
//using Tricentis.Automation.Creation;
//using Tricentis.Automation.Engines.Adapters.Controllers;
//using Tricentis.Automation.Engines.Representations.Attributes;
//using Tricentis.Automation.Engines.Technicals;
//using Tricentis.Automation.Engines.Technicals.Html;

//namespace ARZCustomControl.Html.ArctisKontoSKTable.Adapter.Controller
//{
//    [SupportedAdapter(typeof(ArctisKontoSKCellAdapter))]
//    public class ArctisKontoSKCellAdapterController : ContextAdapterController<ArctisKontoSKCellAdapter>
//    {
//        #region Constructors

//        protected ArctisKontoSKCellAdapterController(ArctisKontoSKCellAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
//        {
//        }

//        #endregion

//        #region Methods

//        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
//        {
//            yield return new TechnicalAssociation("Children");
//        }

//        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
//        {
//            yield return new TechnicalAssociation("ParentNode");
//        }

//        #endregion
//    }
//}
