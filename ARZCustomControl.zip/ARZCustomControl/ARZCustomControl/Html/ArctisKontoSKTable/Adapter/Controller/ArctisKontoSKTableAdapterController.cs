﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoSKTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisKontoSKTableAdapter))]
    public class ArctisKontoSKTableAdapterController : TableContextAdapterController<ArctisKontoSKTableAdapter>
    {
        #region Constructor

        protected ArctisKontoSKTableAdapterController(ArctisKontoSKTableAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }

        #endregion

        #region Methods

        protected override IEnumerable<IAssociation> ResolveAssociation(RowsBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("DLTable");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ColumnsBusinessAssociation businessAssociation)
        {
            throw new NotSupportedException();
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAdapter> SearchAdapters(IAlgorithmicAssociation algorithmicAssociation)
        {
            if(algorithmicAssociation.AlgorithmName == "DLTable")
            {
                var baseAdapters = base.SearchAdapters(algorithmicAssociation);
                var kontoAdapters = baseAdapters.Where(t => t.GetType() == typeof(ArctisKontoSKRowsAdapter));
                return kontoAdapters;
            }
            return base.SearchAdapters(algorithmicAssociation);
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (algorithmicAssociation.AlgorithmName == "DLTable")
            {
                //List<IHtmlDescriptionBaseTechnical> lstTechnicals = ContextAdapter.Technical.Children.Get<IHtmlDescriptionBaseTechnical>().ToList();
                List<IHtmlDescriptionBaseTechnical> lstTechnicals = ContextAdapter.Technical.All?.Get<IHtmlDescriptionBaseTechnical>().ToList();
                return lstTechnicals;
            }
            return base.SearchTechnicals(algorithmicAssociation);
        }

        #endregion
    }
}
