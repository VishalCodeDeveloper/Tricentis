﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoSKTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisKontoSKRowsAdapter))]
    public class ArctisKontoSKRowsAdapterController : TableRowContextAdapterController<ArctisKontoSKRowsAdapter>
    {
        #region Constructors

        protected ArctisKontoSKRowsAdapterController(ArctisKontoSKRowsAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        
        #endregion

        #region Methods

        protected override IEnumerable<IAssociation> ResolveAssociation(CellsBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("qRows");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAdapter> SearchAdapters(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (algorithmicAssociation.AlgorithmName == "qRows")
            {
                var baseAdapters = base.SearchAdapters(algorithmicAssociation);
                var kontoAdapters = baseAdapters.Where(t => t.GetType() == typeof(ArctisKontoSKCellAdapter));
                return kontoAdapters;
            }
            return base.SearchAdapters(algorithmicAssociation);
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (algorithmicAssociation.AlgorithmName == "qRows")
            {
                List<IHtmlElementTechnical> lstTechnicals = ContextAdapter.Technical?.Children?.Get<IHtmlElementTechnical>()?.ToList();
                return lstTechnicals;
            }
            return base.SearchTechnicals(algorithmicAssociation);
        }

        #endregion
    }
}
