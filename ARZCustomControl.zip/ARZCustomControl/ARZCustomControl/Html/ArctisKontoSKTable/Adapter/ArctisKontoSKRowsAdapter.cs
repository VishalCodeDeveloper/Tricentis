﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Generic;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisKontoSKTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlDescriptionBaseTechnical))]
    public class ArctisKontoSKRowsAdapter : AbstractHtmlElementAdapter<IHtmlDescriptionBaseTechnical>, ITableRowAdapter<IHtmlDescriptionBaseTechnical>
    {
        #region Constructors

        protected ArctisKontoSKRowsAdapter(IHtmlDescriptionBaseTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsValidArctisKontoSKRow(technical));
        }

        #endregion

        #region Methods

        public static bool IsValidArctisKontoSKRow(IHtmlElementTechnical technical)
        {
            try
            {
                // && !technical.Attributes.ContainsKey("ExtRegistered")technical.ParentNode.TypeName == "XBrowser:DL"
                if (!technical.TagEquals("dt"))
                {
                    return false;
                }
                if (technical.Id.ToLower() == "head" && 
                    !technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.TypeName.Equals("XBrowser:FORM") && 
                    (technical.ParentNode.Get<IHtmlElementTechnical>().Id.Equals("ListSimple1") || 
                    technical.ParentNode.Get<IHtmlElementTechnical>().ParentNode.Get<IHtmlElementTechnical>().Id.Equals("ListSimple1")))
                {
                    return true;
                }
                if (technical.GetAttribute("key") != null)
                {
                    if (technical.KeyContains("erFqhBEhJARTBalm") || technical.KeyContains("es3ChoyEiARTnauo") || technical.KeyContains("esIwsTrDzARTnbSV"))
                    {
                        return true;
                    }
                    return false;
                }
                return false;
            }
            catch
            {
            }
            return false;
        }

        #endregion
    }
}
