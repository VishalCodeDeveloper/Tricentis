﻿using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisTree.Adapter.Controller
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class ArctisTreeNodeLeafAdapter : ArctisTreeNodeAdapter
    {
        #region Constructors and Destructors
        protected ArctisTreeNodeLeafAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
        }
        #endregion

        #region Properties
        public override bool Expanded => false;

        public override bool Selected => HasBoldChildElement(Technical);

        public override string Name => Technical.VisibleInnerText;
        #endregion

        #region Methods
        protected override bool IsValid()
        {
            return Technical.Tag.ToLower() == "dt";
        }
        #endregion
    }
}
