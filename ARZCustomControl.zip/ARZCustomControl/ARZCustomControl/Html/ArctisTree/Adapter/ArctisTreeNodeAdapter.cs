﻿using System;
using System.Drawing;
using System.Linq;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;

namespace ARZCustomControl.Html.ArctisTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class ArctisTreeNodeAdapter : AbstractHtmlDomNodeAdapter<IHtmlElementTechnical>, ITreeNodeAdapter
    {
        #region Constructors and Destructors
        protected ArctisTreeNodeAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid);
        }
        #endregion

        #region Properties
        public PointF? ExpandCollapsePoint => ActionPoint;

        public virtual bool Expanded { get => (PlusMinusElement?.InnerText ?? "") == "-"; }

        public virtual bool Selected => HasBoldChildElement(SElement);

        public virtual string Name
        {
            get {
                try
                {
                    return SElement.InnerText.Substring(1);
                }
                catch(Exception e)
                {
                    return string.Empty;
                }
            }
        }
        private IHtmlElementTechnical PlusMinusElement
        {
            get {
                return SElement?.Children.Get<IHtmlElementTechnical>().FirstOrDefault(i => i.Tag.ToLower() == "p");
            }
        }


        private IHtmlElementTechnical SElement
        {
            get {
                return Technical.Children.Get<IHtmlElementTechnical>().FirstOrDefault(i => i.Tag.ToLower() == "s");
            }
        }
        #endregion

        #region Public Methods and Operators
        public void Expand()
        {
            ClickNode();
        }

        public void Select()
        {
            ClickNode();
        }

        public void Collapse()
        {
            ClickNode();
        }
        #endregion

        #region Methods
        protected virtual bool IsValid()
        {
            return Technical.Tag.ToLower() == "dd";
        }

        private void ClickNode()
        {
            Technical.ScrollIntoView();

            PointF leftPoint = new PointF(ControlArea.Left + 5, ControlArea.Top + 5);
            Mouse.Jumpy.DoMouseAction(MouseOperation.Click, leftPoint);
        }

        protected static bool HasBoldChildElement(IHtmlElementTechnical tech)
        {
            return tech.Children.Get<IHtmlElementTechnical>().Any(i => i.Tag.ToLower() == "b");
        }

        #endregion
    }
}
