﻿using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisTree.Adapter
{
    [SupportedTechnical(typeof(IHtmlSpanTechnical))]
    public class ArctisTreeAdapter : AbstractHtmlDomNodeAdapter<IHtmlSpanTechnical>, ITreeAdapter
    {
        #region Constructors and Destructors
        protected ArctisTreeAdapter(IHtmlSpanTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsValid(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName => "Custom Arctis Tree";
        #endregion

        #region Public Methods and Operators
        public static bool IsValid(IHtmlSpanTechnical technical)
        {
            return technical.Id.ToLower() == "mloben";
        }
        #endregion
    }
}
