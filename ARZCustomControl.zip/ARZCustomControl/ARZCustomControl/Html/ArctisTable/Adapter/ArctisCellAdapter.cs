﻿using ARZCustomControl.Html.ArctisTable.Adapter;
using System;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Generic;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.SpanTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlElementTechnical))]
    public class ArctisCellAdapter : AbstractHtmlElementAdapter<IHtmlElementTechnical>, ITableCellAdapter<IHtmlElementTechnical>//, IArctisCellAdapter
    {
        #region Constructors and Destructors
        public ArctisCellAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsArctisCell(technical));
        }
        #endregion

        public ArctisCellAdapter NextSiblingCell { get; set; }

        #region Properties
        public int ColSpan => 1;

        public int RowSpan => 1;

        public string Text
        {
            get {
                if(NextSiblingCell != null)
                {
                    return Technical.InnerText + " "+ ((IHtmlElementTechnical)NextSiblingCell.Technical).InnerText;
                }
                return Technical.InnerText;
            }
        }
        #endregion

        #region Methods
        private bool IsArctisCell(IHtmlElementTechnical technical)
        {
            try
            {
                if (!technical.TagEquals("q")/* && !technical.TagEquals("span")*/)
                {
                    return false;
                }
                if (technical.GetAttribute("key") != null && technical.GetAttribute("key").ToLower().Equals("2ndlevel"))
                {
                    if (technical.TagEquals("span"))
                    {
                        string id = technical.Id;
                    }
                        return false;
                }

                //if (technical.TagEquals("span") ) {
                //    string id = technical.Id;
                //    if (!technical.IdEquals("checkboxSpanOther")) {
                //        return false;
                //    }
                    
                //}

                //if (technical.TagEquals("span") && technical.IdEquals("checkboxSpanOther"))
                //{
                //    return true;
                //}

                return true;
                // &&
                //    !String.IsNullOrEmpty(technical.GetAttribute("TOSCAReference"));
            }
            catch (Exception)
            {

                return false;
            }

        }

        public override void ScrollToVisible()
        {
            Technical.ScrollIntoView();
        }
        #endregion
    }
}
