﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Html;

namespace ARZCustomControl.Html.ArctisTable.Adapter
{
    public interface IArctisCellAdapter : IHtmlAdapter
    {
        IArctisCellAdapter brotherElement { get; set; }
    }
}
