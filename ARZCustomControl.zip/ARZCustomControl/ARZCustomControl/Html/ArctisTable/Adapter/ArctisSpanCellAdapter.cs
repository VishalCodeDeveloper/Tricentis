﻿using ARZCustomControl.Html.ArctisTable.Adapter;
using System;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Generic;
using Tricentis.Automation.Engines.Adapters.Html;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.SpanTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlSpanTechnical))]
    class ArctisSpanCellAdapter : HtmlContainerGuiElementAdapter, ITableCellAdapter<IHtmlElementTechnical>, IArctisCellAdapter
    {
        #region Constructors and Destructors
        public ArctisSpanCellAdapter(IHtmlElementTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(IsArctisCell(technical));
        }
        #endregion

        public IArctisCellAdapter brotherElement { get; set; }

        #region Properties
        public int ColSpan => 1;

        public int RowSpan => 1;

        public string Text
        {
            get {
                if(brotherElement != null)
                {
                    return Technical.InnerText + " "+((IHtmlElementTechnical)brotherElement.Technical).InnerText;
                }
                return Technical.InnerText;
            }
        }
        #endregion

        #region Methods
        private bool IsArctisCell(IHtmlElementTechnical technical)
        {
            try
            {
                if (!technical.TagEquals("span"))
                {
                    return false;
                }
                
                if (technical.TagEquals("span") ) {
                    string id = technical.Id;
                    if (!technical.IdEquals("checkboxSpanOther")) {
                        return false;
                    }
                }

                if (technical.TagEquals("span") && technical.IdEquals("checkboxSpanOther"))
                {
                    return true;
                }

                return true;
                // &&
                //    !String.IsNullOrEmpty(technical.GetAttribute("TOSCAReference"));
            }
            catch (Exception)
            {

                return false;
            }

        }

        public override void ScrollToVisible()
        {
            Technical.ScrollIntoView();
        }
        #endregion
    }
}
