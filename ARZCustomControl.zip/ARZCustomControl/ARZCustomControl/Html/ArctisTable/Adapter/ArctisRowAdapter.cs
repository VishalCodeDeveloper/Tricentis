﻿using ARZCustomControl.Html.SpanTable.Adapter;
using System;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Generic;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.ArctisTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlDescriptionBaseTechnical))]
    public class ArctisRowAdapter : AbstractHtmlElementAdapter<IHtmlDescriptionBaseTechnical>, ITableRowAdapter<IHtmlDescriptionBaseTechnical>
    {
        #region Constructors and Destructors
        public ArctisRowAdapter(IHtmlDescriptionBaseTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsValid(technical));
        }
        #endregion

        #region Methods
        public static bool IsValid(IHtmlElementTechnical technical)
        {
            try
            {
                if (!technical.TagEquals("dt") && !technical.TagEquals("dd"))
                {
                    return false;
                }
                if (technical.GetAttribute("key") != null)
                {
                    //if (technical.KeyContains("2ndlevel"))
                    //{
                    //    return false;
                    //}
                    if (technical.KeyContains("listplus1_"))
                    {
                        return true;
                    }
                    if (technical.KeyContains("datenreiter"))
                    {
                        return true;
                    }

                    if (technical.ParentNode.Get<IHtmlElementTechnical>().IdContains("listsimple") && technical.Visible)
                    {
                        return true;
                    }

                    if (CheckParents(technical) && technical.Visible)
                    {
                        return true;
                    }

                    return false;
                }
                if (technical.ParentNode.Get<IHtmlElementTechnical>().IdContains("listplus") && technical.Visible)
                {
                    return true;
                }

                if (technical.TagEquals("dt") && technical.IdEquals("head"))
                {
                    return true;
                }

                if (technical.TagEquals("dt") || technical.TagEquals("dd"))
                {
                    if (CheckParents(technical))
                    {
                        return true;
                    }
                }

                return false;
            }
            catch (Exception)
            {
                return false;
            }

        }

        private static bool CheckParents(IHtmlElementTechnical startElement)
        {
            IHtmlElementTechnical currentElement = startElement.ParentNode.Get<IHtmlElementTechnical>();
            for (int i = 0; i < 500; i++)
            {
                if (currentElement == null)
                {
                    return false;
                }

                if (currentElement.IdContains("listsimple") || currentElement.IdContains("listplus"))
                {
                    return true;
                }

                try
                {
                    currentElement = currentElement.ParentNode.Get<IHtmlElementTechnical>();
                    if (currentElement == null)
                    {
                        return false;
                    }
                }
                catch(Exception e)
                {
                    return false;
                }
            }
            return false;
        }

        public ArctisTableAdapter Table { get; set; }
        #endregion
    }
}
