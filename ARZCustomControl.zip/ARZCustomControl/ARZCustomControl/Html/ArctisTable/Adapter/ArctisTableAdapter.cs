﻿using System;
using System.Drawing;
using System.Linq;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Attributes;
using Tricentis.Automation.Engines.Adapters.Html;
using Tricentis.Automation.Engines.Adapters.Html.Generic;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Simulation;

namespace ARZCustomControl.Html.SpanTable.Adapter
{
    [SupportedTechnical(typeof(IHtmlSpanTechnical))]
    public class ArctisTableAdapter : AbstractHtmlDomNodeAdapter<IHtmlSpanTechnical>, ITableAdapter
    {
        #region Constructors and Destructors
        public ArctisTableAdapter(IHtmlSpanTechnical technical, Validator validator) : base(technical, validator)
        {
            validator.AssertTrue(() => IsArctisTable(technical));
        }
        #endregion

        #region Properties
        public override string DefaultName
        {
            get {
                var form = Technical.Children.Get<IHtmlDOMNodeTechnical>().First();
                if (!String.IsNullOrEmpty(form?.GetAttribute("name")))
                {
                    return form.GetAttribute("name");
                }
                return "Name not found";

            }
        }

        public LoadStrategy LoadStrategy => LoadStrategy.Default;
        #endregion

        #region Methods
        private bool IsArctisTable(IHtmlSpanTechnical technical)
        {
            return technical.Id.Equals("bodyscroller");
        }

        public bool  ExpandAll {
            get{
                return false;
            }
            set {
                var headerContainer = Technical.All.Get<IHtmlElementTechnical>().Where(t => t.TagEquals("dl") && t.IdEquals("ListPlus2")).FirstOrDefault();
                var spanExpander = headerContainer.All.Get<IHtmlSpanTechnical>().FirstOrDefault(q => q.IdEquals("plusplus"));
                if (spanExpander.InnerText == "++") {
                    var spanAdapter = AdapterFactory.CreateAdapters<HtmlContainerGuiElementAdapter>(spanExpander, "Html").FirstOrDefault();
                    Rectangle rect = spanExpander.GetBoundingClientRect();
                    PointF p = new PointF();
                    p.X = rect.X + rect.Width / 2;
                    p.Y = rect.Y + rect.Height / 2;
                    //Mouse.Jumpy.DoMouseAction(MouseOperation.Click, spanAdapter.ActionPoint);
                    spanAdapter.Click();
                }
               
            }
        }
        #endregion
    }
}
