﻿using System;
using System.Collections.Generic;
using System.Linq;
using ARZCustomControl.Html.ArctisTable.Adapter;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;

namespace ARZCustomControl.Html.SpanTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisCellAdapter))]
    class ArctisCellAdapterController : ContextAdapterController<ArctisCellAdapter>
    {
        #region Constructors and Destructors
        public ArctisCellAdapterController(ArctisCellAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("AllChildren");
            //yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }




        protected override IEnumerable<ITechnical> SearchTechnicals(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (algorithmicAssociation.AlgorithmName == "AllChildren")
            {
                return GetAllChildren();
            }
            return base.SearchTechnicals(algorithmicAssociation);
        }

        private IEnumerable<ITechnical> GetAllChildren()
        {
            List<IHtmlElementTechnical> cellContents = new List<IHtmlElementTechnical>();

            IHtmlElementTechnical previousSibling = ContextAdapter.Technical.GetPreviousSibling();
            if (previousSibling != null) {
                if (previousSibling.TagEquals("span") && previousSibling.IdEquals("checkboxSpanOther")) {
                    List<IHtmlElementTechnical> prevSiblingElements = previousSibling.All.Get<IHtmlElementTechnical>().ToList();
                    IHtmlElementTechnical inputelement = prevSiblingElements.FirstOrDefault(i => i.TagEquals("input"));
                    cellContents.AddRange(prevSiblingElements);
                }
            }

            List<IHtmlElementTechnical> allElements = ContextAdapter.Technical.All.Get<IHtmlElementTechnical>().ToList();
            if (allElements.Count > 0) {
                cellContents.AddRange(allElements);
                return cellContents;
            }

            // This whole logic is needed becuase .Children and .All on the cell element in Arctis don't return anything for some unknown reason.
            List<IHtmlElementTechnical> cells = ContextAdapter.Technical.ParentNode.Get<IHtmlElementTechnical>().Children.Get<IHtmlElementTechnical>().ToList();
            int indexOfCell = cells.IndexOf(ContextAdapter.Technical);
            int currentIndex = 1;
            foreach (var child in cells)
            {
                 if (currentIndex == indexOfCell) {
                    cellContents.AddRange(child.Children.Get<IHtmlElementTechnical>());
                 }
                currentIndex++;
            }

            List<IHtmlElementTechnical> cellChildren = new List<IHtmlElementTechnical>(cellContents);
            foreach (var child in cellChildren)
            {
                cellContents.AddRange(child.Children.Get<IHtmlElementTechnical>());
            }
            //List<string> tags = cellContents.Select(t => t.Tag).ToList();
            return cellContents;
        }

        #endregion
    }
}
