﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;
using ARZCustomControl.Html.ArctisTable.Adapter;
using Tricentis.Automation.Engines.Adapters;

namespace ARZCustomControl.Html.SpanTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisTableAdapter))]
    class ArctisTableAdapterController : TableContextAdapterController<ArctisTableAdapter>
    {
        #region Constructors and Destructors
        public ArctisTableAdapterController(ArctisTableAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(RowsBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("rows");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ColumnsBusinessAssociation businessAssociation)
        {
            throw new NotSupportedException();
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(IAlgorithmicAssociation algorithmicAssociation)
        {
            ContextAdapter.Technical.Document.Refresh();
            IEnumerable<IHtmlElementTechnical> searchedTechnicals = new List<IHtmlElementTechnical>();

            if (algorithmicAssociation.AlgorithmName == "rows")
            {
                if (ContextAdapter.Technical.All.Get<IHtmlElementTechnical>().Where(x => x.IdContains("listsimple")).Count() > 0)
                {
                    return ListSimpleElements();
                }
                //reversed
                if (ContextAdapter.Technical.All.Get<IHtmlElementTechnical>().Where(x => x.IdContains("listplus")).Count() > 0)
                {
                    return ListPlusElements();
                }
                
                return ContextAdapter.Technical.All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid);
            }
            return searchedTechnicals.OfType<ITechnical>();
        }

        private List<IHtmlElementTechnical> ListSimpleElements()
        {
            List<IHtmlElementTechnical> foundRows = new List<IHtmlElementTechnical>();
            var simpleList = ContextAdapter.Technical.All.Get<IHtmlElementTechnical>().Where(x => x.IdContains("listsimple")).ToList();
            bool firstHeader = false;
            if (simpleList.Count() == 1)
            {
                foreach (var liste in simpleList)
                {
                    var viableRows = liste.All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid).ToList();

                    int counter = viableRows.Count();
                    List<IHtmlElementTechnical> possibleHeaders = viableRows.Where(x => x.IdContains("head")).ToList();

                    if (possibleHeaders.Count() > 0 && !firstHeader)
                    {
                        List<IHtmlElementTechnical> possibleHeadersWithCells = possibleHeaders.Where(h => h.Children.Get<IHtmlElementTechnical>().Where(c => c.TagEquals("q")).Count() > 1).ToList();
                        if (possibleHeadersWithCells.Count >= 1)
                        {
                            firstHeader = true;
                            foundRows.Add(possibleHeadersWithCells.First());
                        }
                        else {
                            throw new Exception("More that 1 header row was found");
                        }
                    }

                    foundRows.AddRange(viableRows.Where(x => !(x.IdContains("head"))));

                }
            }
            else
            {
                bool firstHeaderFound = false;
                foreach (var liste in simpleList)
                {
                    var viableRows = liste.All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid).ToList();
                    int viaCount = viableRows.Count();
                   // bool firstHeaderFound = false;

                    List<IHtmlElementTechnical> newViableRows = new List<IHtmlElementTechnical>(); ;

                    foreach (IHtmlElementTechnical possibleRow in viableRows)
                    {
                        if (possibleRow.Id.Contains("head"))
                        {
                            if (!firstHeaderFound)
                            {
                                bool isValidHeader = possibleRow.Children.Get<IHtmlElementTechnical>().Where(c => c.TagEquals("q")).Count() > 1;
                                if (isValidHeader)
                                {
                                    firstHeaderFound = true;
                                    newViableRows.Add(possibleRow);
                                    foundRows.Add(possibleRow);
                                }
                                else
                                {
                                    //throw new Exception("More that 1 header row was found");
                                }

                               
                            }
                        }
                        else
                        {
                            if (firstHeaderFound)
                            {
                                newViableRows.Add(possibleRow);
                            }
                        }
                    }
                    int newCount = newViableRows.Count();

                    var subContentElements = newViableRows.Where(x => !(x.IdContains("head")));
                    int abc = subContentElements.Count();
                    if (subContentElements.Count() == 0 && newViableRows.Count() == 0)
                    {
                        continue;
                    }
                    var subRange = viableRows.Where(x => !(x.IdContains("head")));
                    if (subRange.Count() > 0)
                    {

                        int counter = viableRows.Count();
                        if (viableRows.Count() > 0)
                        {
                            if (newViableRows.Where(x => x.IdContains("head")).Count() > 0 && !firstHeader)
                            {
                                firstHeader = true;
                                foundRows.Add(newViableRows.Where(x => x.IdContains("head")).First());
                            }

                            foundRows.AddRange(newViableRows.Where(x => !(x.IdContains("head"))));
                        }
                    }
                }

            }
            return foundRows;
        }

        private List<IHtmlElementTechnical> ListPlusElements()
        {
            List<IHtmlElementTechnical> foundRows = new List<IHtmlElementTechnical>();
            List<IHtmlElementTechnical> dlElements = ContextAdapter.Technical
                .All.Get<IHtmlElementTechnical>()
                .Where(x => x.IdContains("listplus1") && x.TagEquals("dl")).ToList(); //first level header containers
            
            if (dlElements.Count() == 1)
            {
                IEnumerable<IHtmlElementTechnical> possibleRows = dlElements.First().All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid);
                if (possibleRows.Where(x => x.IdContains("head")).Count() > 0)
                {
                    foundRows.Add(possibleRows.First());
                }
                foundRows.AddRange(possibleRows.Where(x => !x.IdContains("head"))); // add all the rest to the end
            }
            if (dlElements.Count() > 1)
            {
                bool firstHeader = false;
                foreach (var dlElement in dlElements)
                {
                    IEnumerable<IHtmlElementTechnical> possibleRows = dlElement.All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid);
                    if (possibleRows.Where(x => x.IdContains("head")).Count() > 0)
                    {
                        if (!firstHeader)
                        {
                            firstHeader = true;
                            foundRows.Add(possibleRows.First());
                        }
                    }
                    else
                    {
                        foundRows.AddRange(possibleRows);
                    }
                }
            }

            dlElements = ContextAdapter.Technical
                .All.Get<IHtmlElementTechnical>()
                .Where(x => x.IdContains("listplus2") && x.TagEquals("dl")).ToList();
            if (dlElements.Count() > 1)
            {
                
                foreach (var dlElement in dlElements)
                {
                    IEnumerable<IHtmlElementTechnical> possibleHeaderRows = dlElement.All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid);
                    List<IHtmlElementTechnical> headers = possibleHeaderRows.Where(x => x.IdContains("head")).ToList();
                    if (headers.Count() > 0)
                    {
                        IHtmlElementTechnical header = headers.First();
                        string innerText = header.InnerHtml;
                        foundRows.Add(header);
                        //break;
                    }
                }


                //body rows containers
                IEnumerable<IHtmlElementTechnical> possibleRows = dlElements.Last().All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid);
                // filter out only rows that belong to the top level
                possibleRows = possibleRows.Where(r => r.KeyContains("listplus2_") && !r.KeyContains("_2ndlevel"));
                foundRows.AddRange(possibleRows);

               
            }
            //else if (dlElements.Count() == 1) {
            //    IEnumerable<IHtmlElementTechnical> possibleRows = dlElements.First().All.Get<IHtmlElementTechnical>().Where(ArctisRowAdapter.IsValid);
            //    if (possibleRows.Where(x => x.IdContains("head")).Count() > 0)
            //    {
            //        foundRows.Add(possibleRows.First());
            //    }
            //}
            return foundRows;
        }

        protected override IEnumerable<IAdapter> SearchAdapters(IAlgorithmicAssociation algorithmicAssociation)
        {
            var adapters = base.SearchAdapters(algorithmicAssociation);
            foreach (var a in adapters)
            {
                if (a is ArctisRowAdapter)
                {
                    ((ArctisRowAdapter)a).Table = ContextAdapter;
                }
            }
            return adapters;
        }
        #endregion
    }
}
