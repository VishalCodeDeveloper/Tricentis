﻿using System;
using System.Collections.Generic;
using System.Linq;
using ARZCustomControl.Html.ArctisTable.Adapter;
using Tricentis.Automation.AutomationInstructions.TestActions;
using Tricentis.Automation.AutomationInstructions.TestActions.Associations;
using Tricentis.Automation.Creation;
using Tricentis.Automation.Engines.Adapters;
using Tricentis.Automation.Engines.Adapters.Controllers;
using Tricentis.Automation.Engines.Representations.Attributes;
using Tricentis.Automation.Engines.Technicals;
using Tricentis.Automation.Engines.Technicals.Html;
using Tricentis.Automation.Engines.Adapters.Html.Generic;

namespace ARZCustomControl.Html.SpanTable.Adapter.Controller
{
    [SupportedAdapter(typeof(ArctisRowAdapter))]
    class ArctisRowAdapterController : TableRowContextAdapterController<ArctisRowAdapter>
    {
        #region Constructors and Destructors
        public ArctisRowAdapterController(ArctisRowAdapter contextAdapter, ISearchQuery query, Validator validator) : base(contextAdapter, query, validator)
        {
        }
        #endregion

        #region Methods
        protected override IEnumerable<IAssociation> ResolveAssociation(ChildrenBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("SubTable");
            //yield return new TechnicalAssociation("Children");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(ParentBusinessAssociation businessAssociation)
        {
            yield return new TechnicalAssociation("ParentNode");
        }

        protected override IEnumerable<IAssociation> ResolveAssociation(CellsBusinessAssociation businessAssociation)
        {
            yield return new AlgorithmicAssociation("Cells");
        }

        protected override IEnumerable<IAdapter> SearchAdapters(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (algorithmicAssociation.AlgorithmName == "Cells")
            {
                List<IAdapter> adapters = base.SearchAdapters(algorithmicAssociation).ToList();
                List<ArctisCellAdapter> cellList = base.SearchAdapters(algorithmicAssociation).OfType<ArctisCellAdapter>().ToList();

                AbstractHtmlElementAdapter<IHtmlElementTechnical> spanAdapter1
                    = (AbstractHtmlElementAdapter<IHtmlElementTechnical>)adapters.FirstOrDefault(c => ((IHtmlElementTechnical)c.Technical).TagEquals("span"));
                string spanID1 = spanAdapter1?.Technical?.Id;


                ArctisCellAdapter spanAdapter = cellList.FirstOrDefault(c => c.Technical.TagEquals("span"));
                string spanID = spanAdapter?.Technical?.Id;
                List<ArctisCellAdapter> correctedList = new List<ArctisCellAdapter>();

                ArctisCellAdapter previousCell = null;
                foreach (ArctisCellAdapter cell in cellList)
                {
                    string id = cell.Id;
                    IHtmlElementTechnical parent = cell.Technical.ParentNode.Get<IHtmlElementTechnical>();
                    List<IHtmlElementTechnical> parentChildren = parent.Children.Get<IHtmlElementTechnical>().ToList();

                    string lastElementId = "";

                    foreach (IHtmlElementTechnical child in parentChildren)
                    {
                        if (lastElementId == "")
                        {
                            if (lastElementId == "" && child == cell.Technical)
                            {
                                correctedList.Add(cell);
                                break;
                            }

                            lastElementId = child.Id;
                            continue;
                        }

                        if (child == cell.Technical)
                        {
                            if (child.Id != lastElementId)
                            {
                                correctedList.Add(cell);
                                break;
                            }
                        }
                        else
                        {
                            lastElementId = child.Id;
                        }
                    }

                    if (previousCell != null)
                    {
                        if (previousCell.Id == cell.Id)
                        {
                            previousCell.NextSiblingCell = cell;
                        }
                        else
                        {
                            previousCell = cell;
                        }
                    }
                    else
                    {
                        previousCell = cell;
                    }
                }
                return correctedList;
            }
            else if (algorithmicAssociation.AlgorithmName == "SubTable")
            {
                List<ArctisNestedTableAdapter> tableList = base.SearchAdapters(algorithmicAssociation).OfType<ArctisNestedTableAdapter>().ToList();
                return tableList;
            }
            else
                return base.SearchAdapters(algorithmicAssociation);
        }

        protected override IEnumerable<ITechnical> SearchTechnicals(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (algorithmicAssociation.AlgorithmName == "Cells")
            {
                if (CheckParentType(ContextAdapter.Technical, "listsimple", 3))
                {
                    return ListSimpleCells(algorithmicAssociation);
                }

                if (CheckParentType(ContextAdapter.Technical, "listplus", 3))
                {
                    return ListPlusCells(algorithmicAssociation);
                }

                return ContextAdapter.Technical.All.Get<IHtmlElementTechnical>();
            }
            if (algorithmicAssociation.AlgorithmName == "SubTable")
            {
                return GetNestedTables();
            }
            return base.SearchTechnicals(algorithmicAssociation);
        }

        private List<IHtmlElementTechnical> ListSimpleHeaderCells()
        {
            List<IHtmlElementTechnical> foundCells = new List<IHtmlElementTechnical>();

            var parentElement = ContextAdapter.Technical.ParentNode.Get<IHtmlElementTechnical>();
            var dtElements = parentElement.Children.Get<IHtmlElementTechnical>().Where(x => x.Tag.ToLower().Equals("dt") && x.IdContains("head")&& x.Children.Get<IHtmlElementTechnical>()?.Count()>1);

            foreach (var dtElement in dtElements)
            {
                foundCells.AddRange(dtElement.All.Get<IHtmlElementTechnical>());
            }

            return foundCells;
        }

        private IEnumerable<ITechnical> ListSimpleCells(IAlgorithmicAssociation algorithmicAssociation)
        {
            if (ContextAdapter.Technical.IdContains("head"))
            {
                return ListSimpleHeaderCells();
            }

            return ContextAdapter.Technical.All.Get<IHtmlElementTechnical>();
        }

        private IEnumerable<ITechnical> ListPlusCells(IAlgorithmicAssociation algorithmicAssociation)
        {
            if(ContextAdapter.Technical.ParentNode.Get<IHtmlElementTechnical>().Children.Get<IHtmlElementTechnical>().Where(x => x.IdContains("head")).Count() > 0)
            {
                return ListPlus1HeaderCells();
            }
            //if (ContextAdapter.Technical.IdContains("head"))
            //{
            //    return ListPlus1HeaderCells();
            //}
            List<IHtmlElementTechnical> alls = ContextAdapter.Technical.All.Get<IHtmlElementTechnical>().ToList();
            IHtmlElementTechnical span = alls.FirstOrDefault(t => t.TagEquals("span"));
            //string spanId = span.Id;
            return alls;
        }

        private List<IHtmlElementTechnical> ListPlus1HeaderCells()
        {
            List<IHtmlElementTechnical> foundCells = new List<IHtmlElementTechnical>();
            IHtmlElementTechnical table = GetTableElement(ContextAdapter.Technical);
            var dlElements = table.All.Get<IHtmlElementTechnical>().Where(x => x.IdContains("listplus1") && x.Tag.ToLower().Equals("dl"));

            if (dlElements.Count() == 1)
            {
                foundCells.AddRange(ContextAdapter.Technical.All.Get<IHtmlElementTechnical>());
            }
            else if (dlElements.Count() > 1)
            {
                var parent = ContextAdapter.Technical.ParentNode.Get<IHtmlElementTechnical>();
                var dtElements = parent.Children.Get<IHtmlElementTechnical>().Where(x => x.Tag.ToLower().Equals("dt"));
                var ddElements = parent.Children.Get<IHtmlElementTechnical>().Where(x => x.Tag.ToLower().Equals("dd"));
                foreach (var dtElement in dtElements)
                {
                    foundCells.AddRange(dtElement.All.Get<IHtmlElementTechnical>());
                }
                foreach (var ddElement in ddElements)
                {
                    foundCells.AddRange(ddElement.All.Get<IHtmlElementTechnical>());
                }

            }
            else if (dlElements.Count() == 0) {
                dlElements = table.All.Get<IHtmlElementTechnical>().Where(x => x.IdContains("listplus2") && x.Tag.ToLower().Equals("dl"));
                IHtmlElementTechnical row = dlElements.FirstOrDefault(x => x.Children.Get<IHtmlDescriptionBaseTechnical>().Any(c => c.IdEquals("head")));
                List<IHtmlElementTechnical> elements = dlElements.ToList();
                if (row != null)
                {
                    foundCells.AddRange(row.All.Get<IHtmlElementTechnical>());
                }
            }

            foreach (var item in foundCells)
            {
               // string t = item.InnerText;
            }
            return foundCells;
        }

        private bool CheckParentType(IHtmlElementTechnical startElement, string searchString, int level)
        {
            IHtmlElementTechnical elementToCheck = startElement.ParentNode.Get<IHtmlElementTechnical>();

            for (int i = 0; i < level; i++)
            {
                if (elementToCheck.IdContains(searchString))
                {
                    return true;
                }
                elementToCheck = elementToCheck.ParentNode.Get<IHtmlElementTechnical>();
            }
            return false;
        }

        private IHtmlElementTechnical GetTableElement(IHtmlElementTechnical startElement)
        {
            IHtmlElementTechnical currentElement = startElement;
            while (!startElement.Tag.ToLower().Equals("body"))
            {
                if (currentElement.Id.Equals("bodyscroller"))
                {
                    return currentElement;
                }
                currentElement = currentElement.ParentNode.Get<IHtmlElementTechnical>();
            }

            return null;
        }

       

        private IEnumerable<ITechnical> GetNestedTables()
        {
            string k = ContextAdapter.Technical.Key();

            IHtmlElementTechnical sibling = ContextAdapter.Technical.GetNextSiblingUsingAll();
            string key = sibling.Key();
            string tag = sibling.Tag;

            if (sibling != null)
            {
                if (ContextAdapter.Technical.Key() != null && (sibling.KeyContains(ContextAdapter.Technical.Key()) || sibling.Key() == null)) // 1st and 2nd level nested table
                {
                    return new List<IHtmlElementTechnical>() { ContextAdapter.Technical };
                }
            }
            return new List<IHtmlElementTechnical>();
        }
        #endregion
    }
}
